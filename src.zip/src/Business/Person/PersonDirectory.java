/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import java.util.ArrayList;

/**
 *
 * @author kal bugrara
 */
public class PersonDirectory {
    
      ArrayList<Person> personlist ;
    
      public PersonDirectory (){
          
       personlist = new ArrayList();

    }

    public Person newPerson(String id) {

        Person p = new Person(id);
        personlist.add(p);
        return p;
    }

    public void removePerson(Person p) {
        personlist.remove(p);
    }

    public ArrayList<Person> getPersonList() {
        return personlist;
    }

    public Person findPerson(String id) {

        for (Person p : personlist) {

            if (p.isMatch(id)) {
                return p;
            }
        }
            return null; //not found after going through the whole list
         }
    

    public Person findPersonByNUID(String nuid) {

        for (Person p : personlist) {

            if (p.getNuid() != null && p.getNuid().equals(nuid)) {
                return p;
            }
        }
        return null;
    }
    
}